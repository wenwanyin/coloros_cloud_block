#!/system/bin/sh
# 安装时自动修正脚本执行权限
MODPATH=${MODPATH:-/dev/null}
chmod 755 "$MODPATH/service.sh" "$MODPATH/uninstall.sh" "$MODPATH/action.sh" \
           "$MODPATH/game_switch.sh" "$MODPATH/menu.sh" 2>/dev/null
exit 0
