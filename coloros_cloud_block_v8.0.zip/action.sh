#!/system/bin/sh
# 动作按钮 = 音量键选择菜单 v2.3 (并行多设备监听)
# 点按钮后 30 秒内按音量键:
#  [音量+] 执行屏蔽脚本 (全量重建, 约1分钟)
#  [音量-] 游戏助手 放行 <-> 断网 (秒切)
#  不按 = 自动退出, 不动任何东西
M=/data/adb/modules/coloros_cloud_block

echo "[菜单] 音量+ = 执行屏蔽脚本(全量) | 音量- = 游戏助手放行/断网 | 30秒不按=退出"

# 上键和下键可能在不同输入设备上; 每个设备各开一个并行监听, 不漏键
DEVS=$(getevent -pl 2>/dev/null | awk '/add device/{d=$NF} /KEY_VOLUME(UP|DOWN)/{print d}' | sort -u)
if [ -z "$DEVS" ]; then
  echo "[!] 找不到音量键设备, 已退出(没动任何东西)"
  exit 1
fi

n=0
for d in $DEVS; do
  n=$((n+1))
  (timeout 31 getevent -c 1 -l "$d" 2>/dev/null | grep -oE 'KEY_VOLUME(UP|DOWN)' | head -1 > "/tmp/kflag_$$_$n") &
done

KEY=""
i=0
while [ "$i" -lt 60 ]; do
  j=1
  while [ "$j" -le "$n" ]; do
    if [ -s "/tmp/kflag_$$_$j" ]; then
      KEY=$(cat "/tmp/kflag_$$_$j")
      break
    fi
    j=$((j+1))
  done
  [ -n "$KEY" ] && break
  sleep 0.5
  i=$((i+1))
done

rm -f /tmp/kflag_$$_*

[ -z "$KEY" ] && { echo "超时未按键, 已退出 (没动任何东西)"; exit 0; }

case "$KEY" in
  KEY_VOLUMEUP)
    echo ">> 已选: 执行屏蔽脚本 (全量重建)"
    sh "$M/service.sh"
    exit 0 ;;
  KEY_VOLUMEDOWN)
    UID_G=$(pm list packages -U 2>/dev/null | grep 'package:com.oplus.games' | sed 's/.*uid://' | tr -d '\r\n')
    [ -z "$UID_G" ] && UID_G=10142
    N=$(iptables -S 2>/dev/null | grep -c "owner --uid-owner $UID_G")
    if [ "$N" -ge 1 ]; then
      echo ">> 已选: 放行游戏助手"
      sh "$M/game_switch.sh" on
    else
      echo ">> 已选: 断网游戏助手"
      sh "$M/game_switch.sh" off
    fi
    exit 0 ;;
esac
echo "超时未按键, 已退出 (没动任何东西)"
