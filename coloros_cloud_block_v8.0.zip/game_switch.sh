#!/system/bin/sh
# 游戏助手网络开关 v1.3 (秒切版)
# 用法: sh game_switch.sh on|off
#  on  = 放行游戏助手联网 (添加游戏时用)
#  off = 断掉游戏助手网络 (日常状态, 防云控)
# v1.3: 只增删游戏助手 UID 断网规则, 秒级完成; 不再重跑 service.sh (旧版约 1 分钟)
M=/data/adb/modules/coloros_cloud_block
C=$M/config.sh

# 动态取 UID (应用重装导致 UID 变了也不怕)
UID_G=$(pm list packages -U 2>/dev/null | grep 'package:com.oplus.games' | sed 's/.*uid://' | tr -d '\r\n')
[ -z "$UID_G" ] && UID_G=10142

case "$1" in
  on)
    sed -i '/^BLOCKED_PKGS=/,/^"$/ s|^.*com.oplus.games.*|  # com.oplus.games        # 游戏空间 (放行中: 可添加游戏)|' $C
    iptables -w 5 -C OC_UID -m owner --uid-owner "$UID_G" -j DROP 2>/dev/null \
      && iptables -w 5 -D OC_UID -m owner --uid-owner "$UID_G" -j DROP \
      && echo "[OK] 游戏助手已放行 (uid=$UID_G)"
    ip6tables -w 5 -C OC6_UID -m owner --uid-owner "$UID_G" -j DROP 2>/dev/null \
      && ip6tables -w 5 -D OC6_UID -m owner --uid-owner "$UID_G" -j DROP 2>/dev/null
    ;;
  off)
    sed -i '/^BLOCKED_PKGS=/,/^"$/ s|^.*com.oplus.games.*|  com.oplus.games           # 游戏空间|' $C
    iptables -w 5 -C OC_UID -m owner --uid-owner "$UID_G" -j DROP 2>/dev/null \
      || iptables -w 5 -A OC_UID -m owner --uid-owner "$UID_G" -j DROP
    ip6tables -w 5 -C OC6_UID -m owner --uid-owner "$UID_G" -j DROP 2>/dev/null \
      || ip6tables -w 5 -A OC6_UID -m owner --uid-owner "$UID_G" -j DROP 2>/dev/null
    echo "[OK] 游戏助手已断网 (uid=$UID_G)"
    ;;
  *)
    echo "用法: sh game_switch.sh on|off"
    exit 0
    ;;
esac
