#!/system/bin/sh
# 游戏助手网络开关 (改用标记文件, 不再修改 config.sh)
# 用法: sh game_switch.sh on|off
#  on = 放行联网(添加游戏时)  off = 断网
M=/data/adb/modules/coloros_cloud_block
MARK="$M/.games_allowed"

# 动态取 UID
UID_G=$(pm list packages -U 2>/dev/null | grep 'package:com.oplus.games uid:' | sed 's/.*uid://' | tr -d '\r\n')
[ -z "$UID_G" ] && UID_G=10142

case "$1" in
  on)
    touch "$MARK"
    if iptables -w 5 -C OC_UID -m owner --uid-owner "$UID_G" -j DROP 2>/dev/null; then
      iptables -w 5 -D OC_UID -m owner --uid-owner "$UID_G" -j DROP
      echo "[OK] 游戏助手已放行 (uid=$UID_G, 标记已写入)"
    else
      echo "[OK] 游戏助手本就放行, 无需改动 (uid=$UID_G)"
    fi
    ip6tables -w 5 -C OC6_UID -m owner --uid-owner "$UID_G" -j DROP 2>/dev/null \
      && ip6tables -w 5 -D OC6_UID -m owner --uid-owner "$UID_G" -j DROP 2>/dev/null
    ;;
  off)
    rm -f "$MARK"
    iptables -w 5 -C OC_UID -m owner --uid-owner "$UID_G" -j DROP 2>/dev/null \
      || iptables -w 5 -A OC_UID -m owner --uid-owner "$UID_G" -j DROP
    ip6tables -w 5 -C OC6_UID -m owner --uid-owner "$UID_G" -j DROP 2>/dev/null \
      || ip6tables -w 5 -A OC6_UID -m owner --uid-owner "$UID_G" -j DROP 2>/dev/null
    echo "[OK] 游戏助手已断网 (uid=$UID_G, 标记已清除)"
    ;;
  *)
    echo "用法: sh game_switch.sh on|off"
    exit 0
    ;;
esac