#!/system/bin/sh
# ============================================================
# ColorOS 云控屏蔽 - 服务脚本 (Magisk/KernelSU/APatch 通用)
# 应用拦截规则: hosts / IP / SNI 域名分流 / UID 断网 / 冻结 / 首装数据清理
# ============================================================
MODDIR=${0%/*}
CONFIG="$MODDIR/config.sh"
LOG_FILE="$MODDIR/block_log.log"
GAMES_MARK="$MODDIR/.games_allowed"

[ -f "$LOG_FILE" ] && : > "$LOG_FILE" || touch "$LOG_FILE"
log() { echo "$(date '+%Y-%m-%d %H:%M:%S') [$1] $2" | tee -a "$LOG_FILE"; }

# DoH 查询函数 (优先 HTTPS 防篡改, 失败回退 HTTP; 输出原始 JSON)
doh_get() { # 用法: doh_get 域名 类型(1=A, 28=AAAA)
    local proto u out
    [ -n "$BUSYBOX_BIN" ] || return 0
    for proto in https http; do
        u="$proto://223.5.5.5/resolve?name=$1&type=$2"
        out=$(timeout 6 "$BUSYBOX_BIN" wget -qO- -T3 "$u" 2>/dev/null)
        if [ -n "$out" ]; then echo "$out"; return 0; fi
    done
    return 0
}

[ "$(id -u)" -eq 0 ] || { log ERR "需要 root 环境"; exit 1; }
[ -f "$CONFIG" ] || { log ERR "未找到配置文件: $CONFIG"; exit 1; }
. "$CONFIG"
USE_NFT=${USE_NFT:-0}

# ---- 并发锁 (busybox flock; 进程退出自动释放, 无残留) ----
BUSYBOX_BIN=""
for _c in /data/adb/ksu/bin/busybox /data/adb/magisk/busybox /system/xbin/busybox /system/bin/busybox; do
    [ -x "$_c" ] && { BUSYBOX_BIN="$_c"; break; }
done
if [ -n "$BUSYBOX_BIN" ] && [ -w "$MODDIR" ]; then
    exec 9>"$MODDIR/.lock"
    LOCK_MSG=$("$BUSYBOX_BIN" flock -n 8 8>&9 2>&1); LOCK_RC=$?
    if [ "$LOCK_RC" = "0" ]; then
        :
    elif [ "$LOCK_RC" = "1" ]; then
        case "$LOCK_MSG" in
            *"not implemented"*|*"not supported"*)
                log WARN "文件系统不支持 flock, 跳过并发锁" ;;
            *)
                log WARN "已有实例在运行, 本次退出"
                exit 0 ;;
        esac
    else
        log WARN "flock 异常(rc=$LOCK_RC), 未加锁继续"
    fi
fi
# ---- 扩展域名并入解析/SNI 流程 (开关见 config.sh) ----
USE_EXTRA_DOMAINS=${USE_EXTRA_DOMAINS:-1}
if [ "$USE_EXTRA_DOMAINS" = "1" ] && [ -n "$EXTRA_DOMAINS" ]; then
    BLOCKED_DOMAINS="$BLOCKED_DOMAINS$EXTRA_DOMAINS"
fi

log INFO "等待系统启动完成..."
i=0
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 3
    i=$((i+1))
    [ "$i" -ge 100 ] && { log WARN "等待超时，继续执行"; break; }
done
log INFO "设备: $(getprop ro.product.name) | ROM: $(getprop ro.build.version.oplusrom) | Android: $(getprop ro.build.version.release) | 内核: $(uname -r)"
log INFO "本次执行时间: $(date '+%F %T') | 防火墙后端: $([ "$USE_NFT" = "1" ] && echo nft || echo iptables/ip6tables)"

trim() {
    local s="$1"
    s="${s%%#*}"
    s="${s#"${s%%[![:space:]]*}"}"
    s="${s%"${s##*[![:space:]]}"}"
    echo "$s"
}

get_uid() {
    local pkg="$1" uid=""
    if [ -r /data/system/packages.list ]; then
        uid=$(awk -v p="$pkg" '$1==p {print $2; exit}' /data/system/packages.list)
        echo "$uid"
        return 0
    fi
    uid=$(timeout 5 cmd package list packages -U "$pkg" 2>/dev/null \
        | sed -n 's/^package:.* uid:\([0-9][0-9]*\).*/\1/p')
    [ -z "$uid" ] && uid=$(timeout 5 pm list packages -U "$pkg" 2>/dev/null \
        | sed -n 's/^package:.* uid:\([0-9][0-9]*\).*/\1/p')
    echo "$uid"
}

# 成员判断(空格/换行分隔均可用), 用于动态 IP 去重
in_list() { case " $(echo $2) " in *" $1 "*) return 0 ;; esac; return 1; }

apply_hosts() {
    local SRC="$MODDIR/system/etc/hosts"
    [ -f "$SRC" ] || { log WARN "未找到模块 hosts 文件"; return 0; }
    # 本模块 hosts 判定改为"mountinfo 路径 + 内容标记"双保险, 不再依赖 mount 输出源路径写法
    if grep -q 'coloros_cloud_block/system/etc/hosts' /proc/self/mountinfo 2>/dev/null \
        || grep -qs '云控/采集' /system/etc/hosts; then
        log INFO "本模块 hosts 已生效, 跳过 bind"
        return 0
    fi
    if mount 2>/dev/null | grep -q ' /system/etc/hosts '; then
        log WARN "hosts 已被其他挂载占用, 本模块 hosts 层跳过 (IP 层不受影响)"
        return 0
    fi
    mount --bind "$SRC" /system/etc/hosts 2>/dev/null \
        && log INFO "hosts 已 bind 挂载" \
        || log WARN "hosts bind 挂载失败(仅靠 IP 阻断)"
}

DOM4=""; DOM6=""
resolve_domains() {
    RES_FAIL=0
    [ -z "$BLOCKED_DOMAINS" ] && return 0
    local d a ips rip ip6s n i j line t ip2 _TMPH
    # 修正: 实测 busybox nslookup 会读 /etc/hosts, 不能用来拿"真实 IP"; 网络解析一律以 DoH 为准
    local bb="$BUSYBOX_BIN"
    # 并行解析全部域名
    n=0
    while IFS= read -r d; do
        d=$(trim "$d"); [ -z "$d" ] && continue
        n=$((n+1))
        (
            ips=""; ip6s=""
            # DoH 直连阿里 DNS(IP 直连, 不读 hosts, 支持 A/AAAA; 优先 HTTPS)
            if [ -n "$bb" ]; then
                doh=$(doh_get "$d" 1)
                ips=$(echo "$doh" | grep -oE '"data":"[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"' \
                    | cut -d'"' -f4 | grep -v '^0\.0\.0\.0$' | tr '\n' ' ' | sed 's/ *$//')
                doh6=$(doh_get "$d" 28)
                ip6s=$(echo "$doh6" | grep -oE '"data":"[0-9a-fA-F:]+"' \
                    | cut -d'"' -f4 | grep -vE '^::$|^::1$' | tr '\n' ' ' | sed 's/ *$//')
            fi
            # 兜底: 系统解析(读 hosts, 仅 hosts 未劫持时有效)
            if [ -z "$ips" ]; then
                command -v getent >/dev/null 2>&1 \
                    && ips=$(timeout 5 getent hosts "$d" 2>/dev/null | awk '{print $1}')
            fi
            if [ -z "$ips" ] && [ -n "$bb" ]; then
                ips=$(timeout 8 "$bb" nslookup "$d" 114.114.114.114 2>/dev/null \
                    | awk '/^Name:/{x=1} x && /^Address [0-9]+:/{print $3; exit}')
                [ -z "$ips" ] && ips=$(timeout 8 "$bb" nslookup "$d" 8.8.8.8 2>/dev/null \
                    | awk '/^Name:/{x=1} x && /^Address [0-9]+:/{print $3; exit}')
            fi
            [ -z "$ips" ] && ips=$(ping -c 1 -W 2 "$d" 2>/dev/null \
                | sed -n '1s/.*(\([0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*\)).*/\1/p')
            if [ -z "$ips" ] && [ -z "$ip6s" ]; then
                echo "F|$d" > "/tmp/domres_$$_$n"
                exit 0
            fi
            a=$(echo "$ips $ip6s" | tr '\n' ' ' | tr -s ' ' | sed 's/^ //; s/ $//')
            case "$a" in
                0.0.0.0|127.*)
                    rip=""
                    # 原 nslookup 会读本机 hosts 拿不到真实 IP, 改用 DoH
                    rip=$(doh_get "$d" 1 | grep -oE '"data":"[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"' \
                        | cut -d'"' -f4 | tr '\n' ' ')
                    echo "H|$d|$a|$rip" > "/tmp/domres_$$_$n"
                    ;;
                *)
                    echo "R|$d|$a" > "/tmp/domres_$$_$n"
                    ;;
            esac
        ) &
    done <<EOF
$BLOCKED_DOMAINS
EOF
    # 等待全部完成
    i=0
    while [ "$i" -lt 70 ]; do
        done_cnt=0
        j=1
        while [ "$j" -le "$n" ]; do
            [ -s "/tmp/domres_$$_$j" ] && done_cnt=$((done_cnt+1))
            j=$((j+1))
        done
        [ "$done_cnt" -ge "$n" ] && break
        sleep 0.5
        i=$((i+1))
    done
    # 汇总结果
    j=1
    while [ "$j" -le "$n" ]; do
        line=$(cat "/tmp/domres_$$_$j" 2>/dev/null)
        if [ -n "$line" ]; then
            t=$(echo "$line" | cut -d'|' -f1)
            d=$(echo "$line" | cut -d'|' -f2)
            case "$t" in
                F) RES_FAIL=$((RES_FAIL+1)); log WARN "解析失败: $d" ;;
                H)
                    a=$(echo "$line" | cut -d'|' -f3)
                    rip=$(echo "$line" | cut -d'|' -f4)
                    log INFO "域名已被本机劫持(hosts): $d -> $a"
                    if [ -n "$rip" ]; then
                        for rip2 in $rip; do
                            case "$rip2" in
                                0.0.0.0|127.*|::|::1|fe80:*) : ;;
                                *.*.*.*)
                                    in_list "$rip2" "$BLOCKED_IPS" && continue
                                    echo "$DOM4" | grep -qx "$rip2" \
                                        || { DOM4="$DOM4
$rip2"; log INFO "补充真实IP拦截: $d -> $rip2"; }
                                    ;;
                            esac
                        done
                    fi
                    ;;
                R)
                    a=$(echo "$line" | cut -d'|' -f3)
                    for ip2 in $a; do
                        case "$ip2" in
                            *:*)
                                if in_list "$ip2" "$BLOCKED_IPS6"; then
                                    log INFO "域名解析(静态表已覆盖,跳过): $d -> $ip2"
                                else
                                    echo "$DOM6" | grep -qx "$ip2" || DOM6="$DOM6
$ip2"
                                    log INFO "域名解析: $d -> $ip2"
                                fi
                                ;;
                            *)
                                if in_list "$ip2" "$BLOCKED_IPS"; then
                                    log INFO "域名解析(静态表已覆盖,跳过): $d -> $ip2"
                                else
                                    echo "$DOM4" | grep -qx "$ip2" || DOM4="$DOM4
$ip2"
                                    log INFO "域名解析: $d -> $ip2"
                                fi
                                ;;
                        esac
                    done
                    ;;
            esac
        fi
        j=$((j+1))
    done
    rm -f /tmp/domres_$$_* "$_TMPH"
}

legacy_cleanup() {
    local MARK="$MODDIR/.legacy_cleaned" ip pkg uid
    [ -f "$MARK" ] && return 0
    log INFO "清理旧版遗留规则(一次性)..."
    if command -v iptables >/dev/null 2>&1; then
        while IFS= read -r ip; do
            ip=$(trim "$ip"); [ -z "$ip" ] && continue
            iptables -w 5 -D INPUT  -s "$ip" -j DROP 2>/dev/null
            iptables -w 5 -D OUTPUT -d "$ip" -j DROP 2>/dev/null
        done <<EOF
$BLOCKED_IPS
EOF
        while IFS= read -r pkg; do
            pkg=$(trim "$pkg"); [ -z "$pkg" ] && continue
            uid=$(get_uid "$pkg"); [ -z "$uid" ] && continue
            iptables -w 5 -D OUTPUT -m owner --uid-owner "$uid" -j DROP 2>/dev/null
            iptables -w 5 -D OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED \
                -m owner --uid-owner "$uid" -j DROP 2>/dev/null
        done <<EOF
$BLOCKED_PKGS
EOF
    fi
    touch "$MARK"
}

apply_iptables() {
    local IPT IP6T ip pkg uid
    IPT=$(command -v iptables)
    IP6T=$(command -v ip6tables)
    [ -z "$IPT" ] && { log ERR "iptables 不存在"; exit 1; }

    $IPT -w 5 -N OC_IN   2>/dev/null; $IPT -w 5 -F OC_IN
    $IPT -w 5 -N OC_OUT  2>/dev/null; $IPT -w 5 -F OC_OUT
    $IPT -w 5 -N OC_UID  2>/dev/null; $IPT -w 5 -F OC_UID
    $IPT -w 5 -C INPUT  -j OC_IN  2>/dev/null || $IPT -w 5 -I INPUT  1 -j OC_IN
    $IPT -w 5 -C OUTPUT -j OC_OUT 2>/dev/null || $IPT -w 5 -I OUTPUT 1 -j OC_OUT
    $IPT -w 5 -C OUTPUT -j OC_UID 2>/dev/null || $IPT -w 5 -I OUTPUT 1 -j OC_UID

    # SNI 精准过滤: 共享 IP 不整段拦截, 出向 443 按 TLS SNI 域名分流
    # AI 放行规则下沉到 OC_SNI 链顶(该链只处理共享IP流量), 9 条替代原来的 9xN 条
    $IPT -w 5 -N OC_SNI 2>/dev/null; $IPT -w 5 -F OC_SNI
    for ap in $AI_ALLOW_PKGS; do
        [ -z "$ap" ] && continue
        auid=$(get_uid "$ap"); [ -z "$auid" ] && continue
        $IPT -w 5 -A OC_SNI -m owner --uid-owner "$auid" -j ACCEPT
    done
    while IFS= read -r sip; do
        sip=$(trim "$sip"); [ -z "$sip" ] && continue
        $IPT -w 5 -I OC_OUT 1 -d "$sip" -j OC_SNI
        log INFO "SNI分流IP: $sip"
    done <<EOF
$SNI_SHARED_IPS
EOF
    while IFS= read -r sd; do
        sd=$(trim "$sd"); [ -z "$sd" ] && continue
        # 范围放宽到512字节; UDP443(QUIC已加密)行仅兜底, 实际拦截主要靠 TCP 行
        $IPT -w 5 -A OC_SNI -p tcp --dport 443 -m string --algo bm --from 5 --to 512 --string "$sd" -j DROP
        $IPT -w 5 -A OC_SNI -p udp --dport 443 -m string --algo bm --from 5 --to 512 --string "$sd" -j DROP
    done <<EOF
$BLOCKED_DOMAINS
EOF
    $IPT -w 5 -A OC_SNI -j RETURN

    while IFS= read -r ip; do
        ip=$(trim "$ip"); [ -z "$ip" ] && continue
        case " $(echo $SNI_SHARED_IPS) " in
            *" $ip "*) log INFO "共享IP跳过整段拦截(交SNI分流): $ip"; continue ;;
        esac
        $IPT -w 5 -A OC_IN  -s "$ip" -j DROP
        $IPT -w 5 -A OC_OUT -d "$ip" -j DROP
        log INFO "阻断静态IP(v4): $ip"
    done <<EOF
$BLOCKED_IPS
EOF
    while IFS= read -r ip; do
        ip=$(trim "$ip"); [ -z "$ip" ] && continue
        case " $(echo $SNI_SHARED_IPS) " in
            *" $ip "*) log INFO "共享IP跳过整段拦截(交SNI分流): $ip"; continue ;;
        esac
        $IPT -w 5 -A OC_IN  -s "$ip" -j DROP
        $IPT -w 5 -A OC_OUT -d "$ip" -j DROP
        log INFO "阻断域名解析IP(v4): $ip"
    done <<EOF
$DOM4
EOF

    $IPT -w 5 -A OC_UID -o lo -j RETURN
    while IFS= read -r pkg; do
        pkg=$(trim "$pkg"); [ -z "$pkg" ] && continue
        if [ "$pkg" = "com.oplus.games" ] && [ -f "$GAMES_MARK" ]; then
            log INFO "游戏助手已放行(标记), 跳过: $pkg"
            continue
        fi
        uid=$(get_uid "$pkg")
        if [ -z "$uid" ]; then
            log WARN "未找到 UID: $pkg"
        elif [ "$uid" = "1000" ] || [ "$uid" = "0" ]; then
            log WARN "跳过系统UID: $pkg uid=$uid(由IP/域名层拦截)"
        else
            $IPT -w 5 -A OC_UID -m owner --uid-owner "$uid" -j DROP
            log INFO "阻断 APP(v4): $pkg uid=$uid"
        fi
    done <<EOF
$BLOCKED_PKGS
EOF

    if [ -n "$IP6T" ]; then
        $IP6T -w 5 -N OC6_IN   2>/dev/null; $IP6T -w 5 -F OC6_IN
        $IP6T -w 5 -N OC6_OUT  2>/dev/null; $IP6T -w 5 -F OC6_OUT
        $IP6T -w 5 -N OC6_UID  2>/dev/null; $IP6T -w 5 -F OC6_UID
        $IP6T -w 5 -C INPUT  -j OC6_IN  2>/dev/null || $IP6T -w 5 -I INPUT  1 -j OC6_IN
        $IP6T -w 5 -C OUTPUT -j OC6_OUT 2>/dev/null || $IP6T -w 5 -I OUTPUT 1 -j OC6_OUT
        $IP6T -w 5 -C OUTPUT -j OC6_UID 2>/dev/null || $IP6T -w 5 -I OUTPUT 1 -j OC6_UID

        while IFS= read -r ip; do
            ip=$(trim "$ip"); [ -z "$ip" ] && continue
            $IP6T -w 5 -A OC6_IN  -s "$ip" -j DROP
            $IP6T -w 5 -A OC6_OUT -d "$ip" -j DROP
            log INFO "阻断 IP(v6): $ip"
        done <<EOF
$BLOCKED_IPS6
$DOM6
EOF

        $IP6T -w 5 -A OC6_UID -o lo -j RETURN
        while IFS= read -r pkg; do
            pkg=$(trim "$pkg"); [ -z "$pkg" ] && continue
            if [ "$pkg" = "com.oplus.games" ] && [ -f "$GAMES_MARK" ]; then
                continue
            fi
            uid=$(get_uid "$pkg")
            if [ -n "$uid" ] && [ "$uid" != "1000" ] && [ "$uid" != "0" ]; then
                $IP6T -w 5 -A OC6_UID -m owner --uid-owner "$uid" -j DROP
            fi
        done <<EOF
$BLOCKED_PKGS
EOF
    else
        log WARN "ip6tables 不存在，跳过 IPv6"
    fi
}

apply_nft() {
    local NFT ip pkg uid
    NFT=$(command -v nft)
    [ -z "$NFT" ] && { log ERR "nft 不存在"; exit 1; }

    $NFT add table inet ocblock 2>/dev/null
    $NFT flush table inet ocblock
    $NFT add chain inet ocblock input  '{ type filter hook input  priority -100; policy accept; }'
    $NFT add chain inet ocblock output '{ type filter hook output priority -100; policy accept; }'
    $NFT add rule inet ocblock output oifname "lo" accept
    log WARN "nft 后端: 无 SNI 分流/AI 放行, 共享 IP 将整体放行(不误伤AI)"

    while IFS= read -r ip; do
        ip=$(trim "$ip"); [ -z "$ip" ] && continue
        case " $(echo $SNI_SHARED_IPS) " in
            *" $ip "*) log INFO "共享IP跳过整段拦截(nft): $ip"; continue ;;
        esac
        $NFT add rule inet ocblock input  ip  saddr "$ip" drop
        $NFT add rule inet ocblock output ip  daddr "$ip" drop
        log INFO "阻断 IP(v4): $ip"
    done <<EOF
$BLOCKED_IPS
$DOM4
EOF
    while IFS= read -r ip; do
        ip=$(trim "$ip"); [ -z "$ip" ] && continue
        $NFT add rule inet ocblock input  ip6 saddr "$ip" drop
        $NFT add rule inet ocblock output ip6 daddr "$ip" drop
        log INFO "阻断 IP(v6): $ip"
    done <<EOF
$BLOCKED_IPS6
$DOM6
EOF
    while IFS= read -r pkg; do
        pkg=$(trim "$pkg"); [ -z "$pkg" ] && continue
        if [ "$pkg" = "com.oplus.games" ] && [ -f "$GAMES_MARK" ]; then
            continue
        fi
        uid=$(get_uid "$pkg")
        if [ -n "$uid" ] && [ "$uid" != "1000" ] && [ "$uid" != "0" ]; then
            $NFT add rule inet ocblock output meta skuid "$uid" drop 2>/dev/null \
                && log INFO "阻断 APP: $pkg uid=$uid" \
                || log WARN "skuid 规则失败: $pkg"
        fi
    done <<EOF
$BLOCKED_PKGS
EOF
}

apply_freeze() {
    local pkg
    FRZ_CNT=0
    while IFS= read -r pkg; do
        pkg=$(trim "$pkg"); [ -z "$pkg" ] && continue
        if pm list packages -d 2>/dev/null | grep -qx "package:$pkg"; then
            log INFO "已冻结: $pkg"
            FRZ_CNT=$((FRZ_CNT+1))
        else
            pm disable-user --user 0 "$pkg" >/dev/null 2>&1 \
                && { log INFO "冻结成功: $pkg"; FRZ_CNT=$((FRZ_CNT+1)); } \
                || log WARN "冻结失败: $pkg"
        fi
    done <<EOF
$FREEZE_PKGS
EOF
}

# ==================== 主流程 ====================
resolve_domains
if [ "${RES_FAIL:-0}" -ge 5 ] && [ "${RETRY_ON_RESOLVE_FAIL:-1}" = "1" ]; then
    log WARN "首次解析失败 ${RES_FAIL} 个域名, 30 秒后重试一次..."
    sleep 30
    resolve_domains
fi
apply_hosts
legacy_cleanup

if [ "$USE_NFT" = "1" ] || ! command -v iptables >/dev/null 2>&1; then
    log INFO "使用 nft 后端"
    apply_nft
else
    log INFO "使用 iptables 后端"
    apply_iptables
fi

apply_freeze

FIRST_RUN_MARKER="$MODDIR/.first_run"
if [ ! -f "$FIRST_RUN_MARKER" ]; then
    _rom=$(getprop ro.build.version.oplusrom 2>/dev/null)
    if echo "$_rom" | grep -qE '^V?16'; then
        log INFO "【首次安装】清理指定应用数据..."
        while IFS= read -r pkg; do
            pkg=$(trim "$pkg"); [ -z "$pkg" ] && continue
            out=$(timeout 30 pm clear "$pkg" 2>&1)
            if echo "$out" | grep -q "Success"; then
                log INFO "清理成功: $pkg"
            else
                log WARN "清理失败/受保护: $pkg"
            fi
        done <<EOF
$FIRST_RUN_CLR_PKGS
EOF
    else
        log WARN "非 ColorOS16 ($_rom): 跳过13包数据清理"
    fi
    touch "$FIRST_RUN_MARKER"
fi

# —— 应用总结 ——
_oc4=$(iptables -S 2>/dev/null | grep -c '^-A OC_')
_oc6=$(ip6tables -S 2>/dev/null | grep -c '^-A OC6_')
_hst=$(mount 2>/dev/null | grep -c ' on /system/etc/hosts ')
log INFO "======== 应用总结 ========"
log INFO "IPv4规则: $_oc4 条 | IPv6规则: $_oc6 条"
if [ "$USE_EXTRA_DOMAINS" = "1" ]; then
    log INFO "扩展域名: 启用($(echo "$EXTRA_DOMAINS" | grep -c .)条)"
else
    log INFO "扩展域名: 已关闭"
fi
log INFO "域名解析IP: $(echo "$DOM4" | grep -c .) v4 / $(echo "$DOM6" | grep -c .) v6 | 冻结包: ${FRZ_CNT:-0} 个 | hosts挂载: $_hst 处"
log INFO "======== 总结结束 ========"
log INFO "全部规则应用完成 ✔"