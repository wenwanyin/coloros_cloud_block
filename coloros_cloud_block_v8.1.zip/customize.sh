#!/system/bin/sh
# 安装时自动修正脚本执行权限
MODPATH=${MODPATH:-/dev/null}
chmod 755 "$MODPATH/service.sh" "$MODPATH/uninstall.sh" "$MODPATH/action.sh" \
           "$MODPATH/game_switch.sh" "$MODPATH/menu.sh" 2>/dev/null

# 升级检测: 已有拦截链 → 老用户覆盖升级, 补标记跳过首次数据清理
# (链重启即清, 不跨卸载残留; 冻结状态持久, 不用于判断)
if iptables -w 5 -S OC_IN >/dev/null 2>&1 || ip6tables -w 5 -S OC6_IN >/dev/null 2>&1; then
    touch "$MODPATH/.first_run" 2>/dev/null
fi
exit 0