#!/system/bin/sh
# ColorOS 云控屏蔽 - 配置文件（屏蔽范围与域名含义请自行问AI，作者不做担保）
USE_NFT=0

# ---- 扩展域名开关 (实测漏网清单; 1=启用, 0=关闭) ----
# 说明: 扩展域名只走 IP/SNI 运行层拦截(不改 hosts), 关闭即完全放行
# AI推理/消息推送/实时通信/云服务 共6条功能强相关域名默认不拦(见下方注释区), 如需拦截请移入上方列表
USE_EXTRA_DOMAINS=1
EXTRA_DOMAINS="
  dhfs.heytapimage.com
  cloudi.browser.heytapmobi.com
  videoclipfs.coloros.com
  oppo-reg.clickwifi.net
  pantanal-sys-cn.allawntech.com
  i.bot.heytapmobi.com
"

# 注: pantanal-sys-cn.allawntech.com 属跨端系统域名(潘塔纳尔), 若跨端互联功能异常, 先将其移出

# ---- 【功能相关·默认不拦】评估后需要可自行加入上方 EXTRA_DOMAINS ----
# aitool-infer-cn.heytapmobi.com   (AI推理)
# htms.heytapmobi.com              (消息/推送)
# rtc-api-cn.heytapmobi.com        (实时通信)
# io75o.ocloud.heytapmobi.com      (云服务)
# ocloud-api-cn.heytapmobi.com     (云服务)
# cloudkit-api-cn.heytapmobi.com   (云服务)

# ---- 解析失败自动重试 (1=启用; 失败>=5个时 30 秒后重试一次) ----
RETRY_ON_RESOLVE_FAIL=1

# ---- 【谨慎候选·默认不加】可能影响功能, 评估后自行加入上方 EXTRA_DOMAINS ----
# weather-api-cn.allawntech.com    (天气服务)
# weather-server.allawntech.com    (天气服务)
# logistics.apps.oppomobile.com    (快递/物流卡片)
# smartcard.apps.coloros.com       (公交卡/卡包)

# ---- 云控 IP (IPv4) ----
BLOCKED_IPS="
  13.213.183.160
  13.214.52.63
  23.32.61.156
  23.32.61.191
  23.33.126.6
  23.33.126.26
  23.33.126.51
  23.33.126.63
  23.35.148.29
  23.35.148.33
  23.35.148.34
  23.35.148.61
  23.39.47.29
  23.39.47.47
  23.39.47.66
  23.49.98.197
  23.49.98.202
  23.49.98.203
  23.49.98.204
  23.49.98.209
  23.49.98.211
  23.49.98.212
  23.49.98.213
  23.49.98.217
  23.49.98.218
  39.156.118.44
  39.156.118.55
  39.156.118.56
  39.156.118.57
  39.156.118.58
  39.156.118.59
  39.156.130.19
  39.156.130.55
  39.156.130.202
  39.156.138.156
  39.156.138.193
  39.156.138.208
  52.77.59.64
  58.242.130.102
  104.84.150.150
  104.84.150.166
  104.84.150.180
  104.84.150.190
  106.3.18.4
  106.38.236.63
  111.13.75.131
  111.13.75.134
  111.13.75.146
  117.133.184.54
  117.133.184.71
  117.133.184.118
  117.133.184.161
  117.133.185.6
  117.133.185.110
  117.133.185.228
  120.232.90.133
  120.232.94.67
  120.232.94.68
  120.232.94.131
  120.233.119.112
  120.233.134.69
  120.233.134.111
  120.236.181.33
  120.236.182.202
  120.238.145.29
  120.238.145.30
  120.238.145.141
  120.238.145.145
  120.238.145.147
  120.238.145.153
  120.238.145.158
  120.240.51.79
  129.227.17.142
  129.227.17.145
  129.227.29.163
  129.227.29.192
  183.232.4.105
  221.179.216.130
  221.179.216.145
  221.179.216.167
"

# ---- 云控 IP (IPv6) ----
BLOCKED_IPS6="
  2600:140b:1e00:1c::172d:7424
  2600:140b:1e00:1c::172d:742c
  2600:140e:6::b81a:5b81
  2600:140e:6::b81a:5b98
  2600:140e:6::b81a:5b9a
  2600:140e:6::b81a:5bec
"

# ---- 云控域名 ----
BLOCKED_DOMAINS="
  mdp-appconf-cn.heytapdownload.com
  mdp-appconf-eu.heytapdl.com
  mdp-appconf-in.heytapdl.com
  mdp-appconf-us.heytapdl.com
  mdp-appconf-sg.heytapdl.com
  obus-cn.dc.heytapmobi.com
  app-sec-cn.heytapmobi.com
  datasec-kmsex-cn.heytapmobi.com
  obus-conf-cn.heytapmobi.com
  obus-dctech-cn.heytapmobi.com
  dc-dragate-cn.heytapmobi.com
  icosa-service-cn-01.allawntech.com
  gc-gamespace-cn.heytapmobi.com
  ocs-cn-south1.heytapcs.com
  ocs-cn-north1.heytapcs.com
  ota-recruit-cn.allawntech.com
  ota-recruit.coloros.com
  component-ota-cn.allawntech.com
  h5fs.coloros.com
  openapi-slp.heytapmobi.com
  push-ads-cn.heytapmobi.com
  uc-track-gl.heytapmobi.com
  api-jits-cn.heytapmobi.com
  apisnd.heytapmobi.com
  obus-dc20123-cn.heytapmobi.com
  obus-dc20058-cn.heytapmobi.com
  obus-dc10-cn.heytapmobi.com
  obus-dc3012-cn.heytapmobi.com
  gslb-cn.cdo.heytapmobi.com
  api.cdo.oppomobile.com
  gslb.cdo.oppomobile.com
  nebula-api-cn.heytapmobi.com
  odin.allawntech.com
  mdp-upgrade-cn.heytapmobi.com
  appconf-ocs.heytapdownload.com
  sau-server-cn.allawntech.com
  cl-data.ads.heytapmobi.com
  stg-data.ads.heytapmobi.com
  sms.ads.heytapmobi.com
  obus-dc10012-cn.heytapmobi.com
  obus-dc2020-cn.heytapmobi.com
  rus-service-cn.allawntech.com
  omes-sec.heytapmobi.com
  adm-smc-cn.heytapmobi.com
  httpdns-push-cn.heytapmobi.com
  adx.ads.heytapmobi.com
  ias-feeds-cn.heytapmobi.com
  activity-cdo.heytapimage.com
  titan.heytap.com
  adsbdfs.heytapimage.com
  bdapi.ads.oppomobile.com
  sidebar-apps-cn.allawntech.com
  classify-app-cn.allawntech.com
  scene-bind-cn.allawntech.com
  newds-api-cn-01.allawntech.com
  iwisdom-apps-cn.allawntech.com
  iwisdom.apps.coloros.com
  api-cn.cdo.heytapmobi.com
  odin-distrib-cn.allawntech.com
  acdp-conf-cn.heytapimage.com
  acdp-conf-sg.heytapimg.com
  jits2.heytapdownload.com
  data.ads.oppomobile.com
  adsfs.heytapimage.com
  b1-data.ads.heytapmobi.com
  ums-rum-cn.heytapimage.com
  moa-upload-online.coloros.com
"

# 名单说明: obus-dc10012/2020 为 AI 识屏算法插件路径, httpdns-push 为系统 httpdns 通道,
# 此三条仅走 SNI/IP 层拦截, 勿加入 hosts(劫持会误伤 AI 识屏/全系统解析)

# ---- SNI 精准过滤共享 IP (与正常服务共用的 IP, 改按 TLS 域名分流) ----
SNI_SHARED_IPS="
  39.156.118.7
  39.156.118.11
  39.156.118.23
  39.156.118.25
  39.156.118.26
  39.156.118.30
  39.156.118.32
  39.156.118.33
  39.156.118.38
  120.238.145.220
  183.232.4.98
  125.77.162.139
  125.77.162.166
  125.77.162.172
  125.77.162.173
  183.61.239.50
  183.61.239.51
  14.152.51.165
  14.152.51.166
  183.47.242.114
  183.47.242.115
  183.61.184.197
  116.31.102.53
  119.147.227.48
  106.3.18.22
  106.3.16.25
  106.3.16.55
  106.3.16.110
  106.3.16.122
  106.3.16.191
  106.3.16.198
  106.39.205.3
  106.39.205.11
  106.39.205.68
  106.39.205.81
  119.147.98.74
  119.147.98.93
  119.147.175.112
  119.147.175.131
  39.156.138.13
  120.236.182.206
  120.240.51.80
  183.240.182.6
  23.55.107.237
  23.55.107.238
  23.49.98.219
  120.232.90.131
  120.232.90.132
  183.232.115.132
  183.232.115.133
  183.232.115.134
  120.241.225.133
  117.133.184.90
  39.136.116.84
  39.136.116.101
  39.136.116.102
  39.136.118.233
"

# ---- AI 功能包 (共享IP上放行, 防止误伤AI功能) ----
AI_ALLOW_PKGS="
  com.oplus.aiunit
  com.oplus.deepthinker
  com.oplus.metis
  com.aiunit.aon
  com.heytap.speechassist
  com.oplus.aiwriter
  com.oplus.aimemory
  com.oplus.aicall
  com.oplus.aiwidgets
"

# ---- 断网应用 (按 UID; uid=1000 系统包自动跳过) ----
BLOCKED_PKGS="
  com.oplus.ota
  com.oplus.romupdate
  com.oplus.athena
  com.oplus.statistics.rom
  com.oplus.logkit
  com.oplus.cosa
  com.heytap.openid
  com.oplus.battery
  com.oplus.powermonitor
  com.oplus.safecenter
  com.coloros.phonemanager
  com.oplus.trafficmonitor
  com.oplus.smartengine
  com.coloros.scenemode
  com.coloros.sceneservice
  com.oplus.games
"

# ---- 冻结应用 ----
FREEZE_PKGS="
  com.heytap.pictorial
  com.oplus.healthservice
"

# ---- 首次安装清理数据 ----
FIRST_RUN_CLR_PKGS="
  com.oplus.battery
  com.coloros.phonemanager
  com.oplus.safecenter
  com.oplus.powermonitor
  com.coloros.sceneservice
  com.oplus.games
  com.coloros.scenemode
  com.oplus.securitypermission
"