#!/system/bin/sh
# 音量键菜单 v1.1 (双设备监听)
# 用法: sh menu.sh  (root 终端里跑, 然后按音量键选)
#  [音量+] 执行屏蔽脚本 (全量重建规则, 约1分钟)
#  [音量-] 游戏助手 断网 <-> 放行 反切 (秒切)
M=/data/adb/modules/coloros_cloud_block

echo "=============================="
echo " 音量键选择操作:"
echo "  [音量+] 执行屏蔽脚本(全量)"
echo "  [音量-] 游戏助手 放行/断网"
echo "  (30秒内按音量键)"
echo "=============================="

EVUP=$(getevent -pl 2>/dev/null | awk '/add device/{d=$NF} /KEY_VOLUMEUP/{print d; exit}')
EVDN=$(getevent -pl 2>/dev/null | awk '/add device/{d=$NF} /KEY_VOLUMEDOWN/{print d; exit}')
if [ -z "$EVUP" ] && [ -z "$EVDN" ]; then
  echo "[!] 找不到音量键设备, 手动跑: sh $M/service.sh 或 sh $M/game_switch.sh on|off"
  exit 1
fi

i=0
while [ "$i" -lt 15 ]; do
  UP=""; DN=""
  [ -n "$EVUP" ] && UP=$(timeout 1 getevent -c 1 -l "$EVUP" 2>/dev/null | grep -m1 'KEY_VOLUMEUP')
  [ -n "$EVDN" ] && DN=$(timeout 1 getevent -c 1 -l "$EVDN" 2>/dev/null | grep -m1 'KEY_VOLUMEDOWN')
  if [ -n "$UP" ]; then
    echo ">> 已选: 执行屏蔽脚本 (全量重建, 约1分钟)"
    sh "$M/service.sh"
    break
  fi
  if [ -n "$DN" ]; then
    UID_G=$(pm list packages -U 2>/dev/null | grep 'package:com.oplus.games' | sed 's/.*uid://' | tr -d '\r\n')
    [ -z "$UID_G" ] && UID_G=10142
    N=$(iptables -S 2>/dev/null | grep -c "owner --uid-owner $UID_G")
    if [ "$N" -ge 1 ]; then
      echo ">> 已选: 放行游戏助手"
      sh "$M/game_switch.sh" on
    else
      echo ">> 已选: 断网游戏助手"
      sh "$M/game_switch.sh" off
    fi
    break
  fi
  i=$((i+1))
done
[ "$i" -ge 15 ] && echo "超时未按键, 已退出 (没动任何东西)"
