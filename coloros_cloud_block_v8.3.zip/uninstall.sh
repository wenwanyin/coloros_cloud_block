#!/system/bin/sh
# ============================================================
# ColorOS 云控屏蔽 - 卸载脚本
# ============================================================
MODDIR=${0%/*}
CONFIG="$MODDIR/config.sh"
[ -f "$CONFIG" ] && . "$CONFIG" || echo "配置文件不存在，仅清理已知残留"

log_un() { echo "$(date '+%Y-%m-%d %H:%M:%S') [卸载] $1"; }
[ "$(id -u)" -eq 0 ] || { echo "需要 root 环境才能卸载"; exit 1; }

trim() {
    local s="$1"
    s="${s%%#*}"
    s="${s#"${s%%[![:space:]]*}"}"
    s="${s%"${s##*[![:space:]]}"}"
    echo "$s"
}

get_uid() {
    local pkg="$1" uid=""
    if [ -r /data/system/packages.list ]; then
        uid=$(awk -v p="$pkg" '$1==p {print $2; exit}' /data/system/packages.list)
        echo "$uid"
        return 0
    fi
    uid=$(timeout 5 cmd package list packages -U "$pkg" 2>/dev/null \
        | sed -n 's/^package:.* uid:\([0-9][0-9]*\).*/\1/p')
    [ -z "$uid" ] && uid=$(timeout 5 pm list packages -U "$pkg" 2>/dev/null \
        | sed -n 's/^package:.* uid:\([0-9][0-9]*\).*/\1/p')
    echo "$uid"
}

# 1. 卸载 hosts 挂载
umount /system/etc/hosts 2>/dev/null && log_un "已卸载 hosts 挂载"

# 2. nft 表
if command -v nft >/dev/null 2>&1; then
    nft delete table inet ocblock 2>/dev/null && log_un "已删除 nft 表"
fi

# 3. iptables 自定义链
for tool in iptables ip6tables; do
    command -v "$tool" >/dev/null 2>&1 || continue
    for c in OC_IN OC_OUT OC_UID OC6_IN OC6_OUT OC6_UID; do
        $tool -w 5 -D INPUT  -j "$c" 2>/dev/null
        $tool -w 5 -D OUTPUT -j "$c" 2>/dev/null
    done
    for c in OC_IN OC_OUT OC_UID OC6_IN OC6_OUT OC6_UID; do
        $tool -w 5 -F "$c" 2>/dev/null
        $tool -w 5 -X "$c" 2>/dev/null
    done
done
log_un "已清理 iptables/ip6tables 自定义链"

# 4. 旧版直加规则兜底
for tool in iptables ip6tables; do
    command -v "$tool" >/dev/null 2>&1 || continue
    while IFS= read -r ip; do
        ip=$(trim "$ip"); [ -z "$ip" ] && continue
        $tool -w 5 -D INPUT  -s "$ip" -j DROP 2>/dev/null
        $tool -w 5 -D OUTPUT -d "$ip" -j DROP 2>/dev/null
    done <<EOF
$BLOCKED_IPS
EOF
    while IFS= read -r pkg; do
        pkg=$(trim "$pkg"); [ -z "$pkg" ] && continue
        uid=$(get_uid "$pkg"); [ -z "$uid" ] && continue
        $tool -w 5 -D OUTPUT -m owner --uid-owner "$uid" -j DROP 2>/dev/null
        $tool -w 5 -D OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED \
            -m owner --uid-owner "$uid" -j DROP 2>/dev/null
    done <<EOF
$BLOCKED_PKGS
EOF
done
log_un "已清理旧版直加规则"

# 5. 恢复冻结
while IFS= read -r pkg; do
    pkg=$(trim "$pkg"); [ -z "$pkg" ] && continue
    pm enable "$pkg" >/dev/null 2>&1
done <<EOF
$FREEZE_PKGS
EOF
log_un "已尝试恢复所有冻结应用"

# 6. 残留文件
rm -f "$MODDIR/.first_run" "$MODDIR/.legacy_cleaned" "$MODDIR/block_log.log"
log_un "残留文件已清理"
echo "【完成】模块已卸载，规则与冻结全部恢复（建议重启一次）"