#!/system/bin/sh
# ============================================================
# ColorOS 云控屏蔽 - 配置文件
# 支持行内注释:  内容  # 注释     (脚本自动剥掉 # 及之后内容)
# 支持独立注释行: # 注释          (整行跳过)
# 警告: 注释里不要出现 双引号 " 、美元符 $ 、反引号 ` ，
#       否则会破坏字符串或触发变量展开
# 不存在的包/域名/IP 会被自动跳过，多写无害
# ============================================================

# 防火墙后端: 0=iptables/ip6tables(默认,兼容性最好)  1=nft(系统一般不带 nft 命令,别用)
USE_NFT=0

# —— 1. 云控 IP 屏蔽列表（IPv4） ——
# 旧名单保留; 大段已删(误伤大于收益), 域名层已覆盖真实端点
BLOCKED_IPS="
  129.227.29.163    # AWS 新加坡节点-云控入口
  13.214.52.63      # AWS 新加坡节点-云控入口
  52.77.59.64       # AWS 新加坡节点-云控入口
  129.227.17.145    # AWS 新加坡节点-云控入口
  58.242.130.102    # 联通节点-云控国内入口
  129.227.29.192    # AWS 新加坡节点-云控入口
  13.213.183.160    # AWS 新加坡节点-云控入口
  129.227.17.142    # AWS 新加坡节点-云控入口
  106.38.236.63     # 国内云节点-云控入口
  106.3.18.4        # 国内云节点-云控入口
"

# —— 1b. 云控 IP 屏蔽列表（IPv6，没有就留空） ——
BLOCKED_IPS6="
"

# —— 1c. 云控域名（解析真实 IP 加入阻断）——
BLOCKED_DOMAINS="
  mdp-appconf-cn.heytapdownload.com  # NearX云控配置(uid1000桶实测)
  mdp-appconf-eu.heytapdl.com        # 欧洲云控配置(防地区改写开洞)
  mdp-appconf-in.heytapdl.com        # 印度云控配置(同上)
  mdp-appconf-us.heytapdl.com        # 美国云控配置(同上)
  mdp-appconf-sg.heytapdl.com        # 东南亚云控配置(同上)
  obus-cn.dc.heytapmobi.com          # 云控数据总线(管家/游戏/浏览器/账号共用)
  app-sec-cn.heytapmobi.com          # 应用安全云查(securitypermission常驻连接)
  datasec-kmsex-cn.heytapmobi.com    # 数据安全KMS
  obus-conf-cn.heytapmobi.com        # 云控配置(浏览器)
  obus-dctech-cn.heytapmobi.com      # 云控技术上报
  dc-dragate-cn.heytapmobi.com       # ROM统计上报(statistics.rom实测)
  icosa-service-cn-01.allawntech.com # 游戏空间云控
  gc-gamespace-cn.heytapmobi.com     # 游戏空间调度配置
  ocs-cn-south1.heytapcs.com         # 游戏云控南节点
  ocs-cn-north1.heytapcs.com         # 游戏云控北节点
  ota-recruit-cn.allawntech.com      # OTA招募推送
  ota-recruit.coloros.com            # OTA招募推送
  component-ota-cn.allawntech.com    # OTA固件组件
  h5fs.coloros.com                   # OTA相关
  openapi-slp.heytapmobi.com         # ColorDirect服务
  push-ads-cn.heytapmobi.com         # 推送广告(uid1000)
  httpdns-push-cn.heytapmobi.com     # 推送HttpDNS(uid1000)
  uc-track-gl.heytapmobi.com         # UC埋点(浏览器/全局搜索)
  api-jits-cn.heytapmobi.com         # 系统广告/推荐
  apisnd.heytapmobi.com              # 系统广告/推荐
"

# —— 2. 阻止联网的包（按 UID 断网; uid=1000 的系统包会被自动跳过,由 IP/域名层兜底） ——
BLOCKED_PKGS="
  # OTA/更新
  com.oplus.ota             # 系统 OTA
  com.oplus.romupdate       # 系统更新器
  # 云控中枢/上报
  com.oplus.athena          # 云控/推送下发中枢
  com.oplus.statistics.rom  # 使用统计上报(实测12SYN)
  com.oplus.logkit          # 日志采集上报
  com.oplus.cosa            # COSA 广告/推荐引擎
  com.heytap.openid         # 广告设备标识
  # 性能/省电/管家
  com.oplus.battery         # 电池服务(省电策略云控)
  com.oplus.powermonitor    # 功耗监控(降频策略云控)
  com.oplus.safecenter      # 安全中心
  com.coloros.phonemanager  # 手机管家
  com.oplus.trafficmonitor  # 流量统计
  # 调度/场景(断其云控, 代价是失去预加载/场景切换)
  com.oplus.smartengine     # 智慧引擎(应用预加载/性能调度)
  com.coloros.scenemode     # 场景模式策略
  # AI(放行: 保留小布/AI功能)
  com.coloros.sceneservice  # 场景服务
  # 游戏中心
  com.oplus.games           # 游戏空间
"

# —— 3. 冻结的包（完全不运行, 最干净） ——
FREEZE_PKGS="
  com.heytap.pictorial      # 锁屏杂志
  # 负一屏恢复使用
  com.heytap.mcs            # 欢太推送服务
  # AI相关, 已解冻(省电代价接受)
  # com.oplus.pantanal.ums   # 潘塔纳尔跨端服务(AI放开后带活, 常驻6连接, 不用跨端设备就冻着)
"

# —— 4. 首次安装后清理数据（仅一次） ——
FIRST_RUN_CLR_PKGS="
  com.oplus.battery
  com.oplus.cosa
  com.oplus.athena
  com.coloros.phonemanager
  com.oplus.safecenter
  com.oplus.powermonitor
  com.oplus.aiunit
  com.coloros.sceneservice
  com.oplus.deepthinker
  com.oplus.metis
  com.oplus.games
  com.coloros.scenemode
  com.oplus.securitypermission
"
