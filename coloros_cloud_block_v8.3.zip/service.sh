#!/system/bin/sh
# ============================================================
# ColorOS 云控屏蔽 - 服务脚本 (Magisk/KernelSU/APatch 通用)
# ============================================================
MODDIR=${0%/*}
CONFIG="$MODDIR/config.sh"
LOG_FILE="$MODDIR/block_log.log"

[ -f "$LOG_FILE" ] && : > "$LOG_FILE" || touch "$LOG_FILE"
log() { echo "$(date '+%Y-%m-%d %H:%M:%S') [$1] $2" | tee -a "$LOG_FILE"; }

[ "$(id -u)" -eq 0 ] || { log ERR "需要 root 环境"; exit 1; }
[ -f "$CONFIG" ] || { log ERR "未找到配置文件: $CONFIG"; exit 1; }
. "$CONFIG"
USE_NFT=${USE_NFT:-0}

log INFO "等待系统启动完成..."
i=0
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 3
    i=$((i+1))
    [ "$i" -ge 100 ] && { log WARN "等待超时，继续执行"; break; }
done
log INFO "设备: $(getprop ro.product.name) | ROM: $(getprop ro.build.version.oplusrom) | Android: $(getprop ro.build.version.release) | 内核: $(uname -r)"
log INFO "本次执行时间: $(date '+%F %T') | 防火墙后端: $([ "$USE_NFT" = "1" ] && echo nft || echo iptables/ip6tables)"

trim() {
    local s="$1"
    s="${s%%#*}"
    s="${s#"${s%%[![:space:]]*}"}"
    s="${s%"${s##*[![:space:]]}"}"
    echo "$s"
}

get_uid() {
    local pkg="$1" uid=""
    if [ -r /data/system/packages.list ]; then
        uid=$(awk -v p="$pkg" '$1==p {print $2; exit}' /data/system/packages.list)
        echo "$uid"
        return 0
    fi
    uid=$(timeout 5 cmd package list packages -U "$pkg" 2>/dev/null \
        | sed -n 's/^package:.* uid:\([0-9][0-9]*\).*/\1/p')
    [ -z "$uid" ] && uid=$(timeout 5 pm list packages -U "$pkg" 2>/dev/null \
        | sed -n 's/^package:.* uid:\([0-9][0-9]*\).*/\1/p')
    echo "$uid"
}

apply_hosts() {
    local SRC="$MODDIR/system/etc/hosts"
    [ -f "$SRC" ] || { log WARN "未找到模块 hosts 文件"; return 0; }
    umount -l /system/etc/hosts 2>/dev/null
    sleep 1
    mount --bind "$SRC" /system/etc/hosts 2>/dev/null \
        && log INFO "hosts 已 bind 挂载" \
        || log WARN "hosts bind 挂载失败(仅靠 IP 阻断)"
}

DOM4=""; DOM6=""
resolve_domains() {
    [ -z "$BLOCKED_DOMAINS" ] && return 0
    local resolver d a ips
    if command -v getent >/dev/null 2>&1; then
        resolver=getent
    elif command -v ping >/dev/null 2>&1; then
        resolver=ping
    else
        log WARN "无 getent/ping，域名解析不可用(仅靠 hosts)"
        return 0
    fi
    while IFS= read -r d; do
        d=$(trim "$d"); [ -z "$d" ] && continue
        ips=""
        if [ "$resolver" = "getent" ]; then
            ips=$(getent hosts "$d" 2>/dev/null | awk '{print $1}')
        else
            ips=$(ping -c 1 -W 2 "$d" 2>/dev/null | sed -n '1s/.*(\([0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*\)).*/\1/p')
        fi
        [ -z "$ips" ] && { log WARN "解析失败: $d"; continue; }
        for a in $ips; do
            case "$a" in
                0.0.0.0|127.*|::|::1|fe80:*) continue ;;
                *:*) DOM6="$DOM6
$a" ;;
                *)   DOM4="$DOM4
$a" ;;
            esac
            log INFO "域名解析: $d -> $a"
        done
    done <<EOF
$BLOCKED_DOMAINS
EOF
}

legacy_cleanup() {
    local MARK="$MODDIR/.legacy_cleaned" ip pkg uid
    [ -f "$MARK" ] && return 0
    log INFO "清理旧版遗留规则(一次性)..."
    if command -v iptables >/dev/null 2>&1; then
        while IFS= read -r ip; do
            ip=$(trim "$ip"); [ -z "$ip" ] && continue
            iptables -w 5 -D INPUT  -s "$ip" -j DROP 2>/dev/null
            iptables -w 5 -D OUTPUT -d "$ip" -j DROP 2>/dev/null
        done <<EOF
$BLOCKED_IPS
EOF
        while IFS= read -r pkg; do
            pkg=$(trim "$pkg"); [ -z "$pkg" ] && continue
            uid=$(get_uid "$pkg"); [ -z "$uid" ] && continue
            iptables -w 5 -D OUTPUT -m owner --uid-owner "$uid" -j DROP 2>/dev/null
            iptables -w 5 -D OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED \
                -m owner --uid-owner "$uid" -j DROP 2>/dev/null
        done <<EOF
$BLOCKED_PKGS
EOF
    fi
    touch "$MARK"
}

apply_iptables() {
    local IPT IP6T ip pkg uid
    IPT=$(command -v iptables)
    IP6T=$(command -v ip6tables)
    [ -z "$IPT" ] && { log ERR "iptables 不存在"; exit 1; }

    $IPT -w 5 -N OC_IN   2>/dev/null; $IPT -w 5 -F OC_IN
    $IPT -w 5 -N OC_OUT  2>/dev/null; $IPT -w 5 -F OC_OUT
    $IPT -w 5 -N OC_UID  2>/dev/null; $IPT -w 5 -F OC_UID
    $IPT -w 5 -C INPUT  -j OC_IN  2>/dev/null || $IPT -w 5 -I INPUT  1 -j OC_IN
    $IPT -w 5 -C OUTPUT -j OC_OUT 2>/dev/null || $IPT -w 5 -I OUTPUT 1 -j OC_OUT
    $IPT -w 5 -C OUTPUT -j OC_UID 2>/dev/null || $IPT -w 5 -I OUTPUT 1 -j OC_UID

    while IFS= read -r ip; do
        ip=$(trim "$ip"); [ -z "$ip" ] && continue
        $IPT -w 5 -A OC_IN  -s "$ip" -j DROP
        $IPT -w 5 -A OC_OUT -d "$ip" -j DROP
        log INFO "阻断静态IP(v4): $ip"
    done <<EOF
$BLOCKED_IPS
EOF
    while IFS= read -r ip; do
        ip=$(trim "$ip"); [ -z "$ip" ] && continue
        $IPT -w 5 -A OC_IN  -s "$ip" -j DROP
        $IPT -w 5 -A OC_OUT -d "$ip" -j DROP
        log INFO "阻断域名解析IP(v4): $ip"
    done <<EOF
$DOM4
EOF

    $IPT -w 5 -A OC_UID -o lo -j RETURN
    while IFS= read -r pkg; do
        pkg=$(trim "$pkg"); [ -z "$pkg" ] && continue
        uid=$(get_uid "$pkg")
        if [ -z "$uid" ]; then
            log WARN "未找到 UID: $pkg"
        elif [ "$uid" = "1000" ] || [ "$uid" = "0" ]; then
            log WARN "跳过系统UID: $pkg uid=$uid(由IP/域名层拦截)"
        else
            $IPT -w 5 -A OC_UID -m owner --uid-owner "$uid" -j DROP
            log INFO "阻断 APP(v4): $pkg uid=$uid"
        fi
    done <<EOF
$BLOCKED_PKGS
EOF

    if [ -n "$IP6T" ]; then
        $IP6T -w 5 -N OC6_IN   2>/dev/null; $IP6T -w 5 -F OC6_IN
        $IP6T -w 5 -N OC6_OUT  2>/dev/null; $IP6T -w 5 -F OC6_OUT
        $IP6T -w 5 -N OC6_UID  2>/dev/null; $IP6T -w 5 -F OC6_UID
        $IP6T -w 5 -C INPUT  -j OC6_IN  2>/dev/null || $IP6T -w 5 -I INPUT  1 -j OC6_IN
        $IP6T -w 5 -C OUTPUT -j OC6_OUT 2>/dev/null || $IP6T -w 5 -I OUTPUT 1 -j OC6_OUT
        $IP6T -w 5 -C OUTPUT -j OC6_UID 2>/dev/null || $IP6T -w 5 -I OUTPUT 1 -j OC6_UID

        while IFS= read -r ip; do
            ip=$(trim "$ip"); [ -z "$ip" ] && continue
            $IP6T -w 5 -A OC6_IN  -s "$ip" -j DROP
            $IP6T -w 5 -A OC6_OUT -d "$ip" -j DROP
            log INFO "阻断 IP(v6): $ip"
        done <<EOF
$BLOCKED_IPS6
$DOM6
EOF

        $IP6T -w 5 -A OC6_UID -o lo -j RETURN
        while IFS= read -r pkg; do
            pkg=$(trim "$pkg"); [ -z "$pkg" ] && continue
            uid=$(get_uid "$pkg")
            if [ -n "$uid" ] && [ "$uid" != "1000" ] && [ "$uid" != "0" ]; then
                $IP6T -w 5 -A OC6_UID -m owner --uid-owner "$uid" -j DROP
            fi
        done <<EOF
$BLOCKED_PKGS
EOF
    else
        log WARN "ip6tables 不存在，跳过 IPv6"
    fi
}

apply_nft() {
    local NFT ip pkg uid
    NFT=$(command -v nft)
    [ -z "$NFT" ] && { log ERR "nft 不存在"; exit 1; }

    $NFT add table inet ocblock 2>/dev/null
    $NFT flush table inet ocblock
    $NFT add chain inet ocblock input  '{ type filter hook input  priority -100; policy accept; }'
    $NFT add chain inet ocblock output '{ type filter hook output priority -100; policy accept; }'
    $NFT add rule inet ocblock output oifname "lo" accept

    while IFS= read -r ip; do
        ip=$(trim "$ip"); [ -z "$ip" ] && continue
        $NFT add rule inet ocblock input  ip  saddr "$ip" drop
        $NFT add rule inet ocblock output ip  daddr "$ip" drop
        log INFO "阻断 IP(v4): $ip"
    done <<EOF
$BLOCKED_IPS
$DOM4
EOF
    while IFS= read -r ip; do
        ip=$(trim "$ip"); [ -z "$ip" ] && continue
        $NFT add rule inet ocblock input  ip6 saddr "$ip" drop
        $NFT add rule inet ocblock output ip6 daddr "$ip" drop
        log INFO "阻断 IP(v6): $ip"
    done <<EOF
$BLOCKED_IPS6
$DOM6
EOF
    while IFS= read -r pkg; do
        pkg=$(trim "$pkg"); [ -z "$pkg" ] && continue
        uid=$(get_uid "$pkg")
        if [ -n "$uid" ] && [ "$uid" != "1000" ] && [ "$uid" != "0" ]; then
            $NFT add rule inet ocblock output meta skuid "$uid" drop 2>/dev/null \
                && log INFO "阻断 APP: $pkg uid=$uid" \
                || log WARN "skuid 规则失败: $pkg"
        fi
    done <<EOF
$BLOCKED_PKGS
EOF
}

apply_freeze() {
    local pkg
    while IFS= read -r pkg; do
        pkg=$(trim "$pkg"); [ -z "$pkg" ] && continue
        if pm list packages -d 2>/dev/null | grep -qx "package:$pkg"; then
            log INFO "已冻结: $pkg"
        else
            pm disable-user --user 0 "$pkg" >/dev/null 2>&1 \
                && log INFO "冻结成功: $pkg" \
                || log WARN "冻结失败: $pkg"
        fi
    done <<EOF
$FREEZE_PKGS
EOF
}

# ==================== 主流程 ====================
resolve_domains
apply_hosts
legacy_cleanup

if [ "$USE_NFT" = "1" ] || ! command -v iptables >/dev/null 2>&1; then
    log INFO "使用 nft 后端"
    apply_nft
else
    log INFO "使用 iptables 后端"
    apply_iptables
fi

apply_freeze

FIRST_RUN_MARKER="$MODDIR/.first_run"
if [ ! -f "$FIRST_RUN_MARKER" ]; then
    _rom=$(getprop ro.build.version.oplusrom 2>/dev/null)
    if echo "$_rom" | grep -qE '^V?16'; then
        log INFO "【首次安装】清理指定应用数据..."
        while IFS= read -r pkg; do
            pkg=$(trim "$pkg"); [ -z "$pkg" ] && continue
            out=$(timeout 30 pm clear "$pkg" 2>&1)
            if echo "$out" | grep -q "Success"; then
                log INFO "清理成功: $pkg"
            else
                log WARN "清理失败/受保护: $pkg"
            fi
        done <<EOF
$FIRST_RUN_CLR_PKGS
EOF
    else
        log WARN "非 ColorOS16 ($_rom): 跳过13包数据清理"
    fi
    touch "$FIRST_RUN_MARKER"
fi

# —— 应用总结 ——
_oc4=$(iptables -S 2>/dev/null | grep -c '^-A OC_')
_oc6=$(ip6tables -S 2>/dev/null | grep -c '^-A OC6_')
_frz=$(pm list packages -d 2>/dev/null | grep -c 'package:')
_hst=$(mount 2>/dev/null | grep -c ' on /system/etc/hosts ')
log INFO "======== 应用总结 ========"
log INFO "IPv4规则: $_oc4 条 | IPv6规则: $_oc6 条"
log INFO "域名解析IP: $(echo "$DOM4" | grep -c .) v4 / $(echo "$DOM6" | grep -c .) v6 | 冻结/禁用包: $_frz 个 | hosts挂载: $_hst 处"
log INFO "======== 总结结束 ========"
log INFO "全部规则应用完成 ✔"